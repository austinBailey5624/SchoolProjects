function answersLookup = BackwardSubstitutionMBlocks(data)
answers = Gaussian(data);
answersLookup = BackwardSubstitution(answers);
