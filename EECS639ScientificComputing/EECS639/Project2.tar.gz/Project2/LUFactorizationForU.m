function result = LUFactorizationForU(data)

result = Gaussian(data);