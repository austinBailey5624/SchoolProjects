% Script P1D
% Illustrates Eperimeter

[C_inner, C_outer] = Eperimeter(3, 2, 10000);