function angles = gimmeAngles( n )
x = n + 1;
angles = (2 * pi * ( i(1:1:x) - 1 ) ) / n;
