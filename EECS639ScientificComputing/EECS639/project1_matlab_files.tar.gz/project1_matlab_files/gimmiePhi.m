function Kappa2 = gimmiePhi(Kappa)
Kappa2 = atan(Kappa.B/(Kappa.A-Kappa.C));