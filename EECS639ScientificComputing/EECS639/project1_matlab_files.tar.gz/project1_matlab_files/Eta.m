function Kappa3 = Eta(Kappa)
phi = gimmiePhi(Kappa);
if(Kappa.A